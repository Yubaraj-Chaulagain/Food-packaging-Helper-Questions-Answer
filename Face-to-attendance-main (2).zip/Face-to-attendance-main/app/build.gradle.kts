
plugins {
    id("com.android.application")
}

android {
    namespace = "com.fulkumari.farattendance"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.fulkumari.farattendance"

        minSdk = 23
        targetSdk = 35

        versionCode = 2
        versionName = "1.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.core:core:1.13.1")
}
